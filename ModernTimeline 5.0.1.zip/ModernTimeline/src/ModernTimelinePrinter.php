<?php
declare( strict_types = 1 );
namespace ModernTimeline;
include_once('extensions/ModernTimeline/src/Event.php');
include_once('extensions/ModernTimeline/src/EventExtractor.php');
include_once('extensions/ModernTimeline/src/JsonBuilder.php');
include_once('extensions/ModernTimeline/src/TimelineOptions.php');
include_once('extensions/ModernTimeline/src/ResultFacade/ResultPresenter.php');
include_once('extensions/ModernTimeline/src/SlidePresenter/SlidePresenter.php');
include_once('extensions/ModernTimeline/src/TimelinePresenter.php');
include_once('extensions/ModernTimeline/src/ResultFacade/PropertyValueCollection.php');
include_once('extensions/ModernTimeline/src/ResultFacade/PropertyValueCollections.php');
include_once('extensions/ModernTimeline/src/ResultFacade/ResultFormat.php');
include_once('extensions/ModernTimeline/src/ResultFacade/ResultFormatRegistrator.php');
include_once('extensions/ModernTimeline/src/ResultFacade/ResultFormatRegistry.php');
include_once('extensions/ModernTimeline/src/ResultFacade/ResultSimplifier.php');
include_once('extensions/ModernTimeline/src/ResultFacade/SimpleQueryResult.php');
include_once('extensions/ModernTimeline/src/ResultFacade/Subject.php');
include_once('extensions/ModernTimeline/src/ResultFacade/SubjectCollection.php');
include_once('extensions/ModernTimeline/src/SlidePresenter/SimpleSlidePresenter.php');
include_once('extensions/ModernTimeline/src/SlidePresenter/TemplateSlidePresenter.php');
use ModernTimeline\ResultFacade\PropertyValueCollection;
use ModernTimeline\ResultFacade\PropertyValueCollections;
use ModernTimeline\ResultFacade\ResultFormat;
use ModernTimeline\ResultFacade\ResultFormatRegistrator;
use ModernTimeline\ResultFacade\ResultFormatRegistry;
#use ModernTimeline\ResultFacade\ResultPresenter;
use ModernTimeline\ResultFacade\ResultSimplifier;
use ModernTimeline\ResultFacade\SimpleQueryResult;
use ModernTimeline\ResultFacade\Subject;
use ModernTimeline\ResultFacade\SubjectCollection;
use ParamProcessor\Param;
use ParamProcessor\ProcessedParam;
use ParamProcessor\ProcessingResult;
use SMW\Parser\RecursiveTextProcessor;
use SMW\Query\QueryResult;
use SMW\Query\ResultPrinter;
use SMWQuery;

class ModernTimelinePrinter implements ResultPrinter {

    private ResultFormat $format;

    public function __construct() {
        $registry = new ResultFormatRegistry();

        $registry->newFormat()
            ->withName( 'moderntimeline' )
            ->andMessageKey( 'modern-timeline-format-name' )
            ->andParameterDefinitions( TimelineOptions::getTimelineParameterDefinitions() )
            ->andPresenterBuilder( function() {
                return new TimelinePresenter();
            } )
            ->register();

        $this->format = $registry->getFormatByName( 'moderntimeline' );
    }

    public function getName(): string {
        return wfMessage( $this->format->getNameMessageKey() )->text();
    }

    public function getParamDefinitions( array $definitions ) {
        return array_merge( $definitions, $this->format->getParameterDefinitions() );
    }

    /**
     * @param QueryResult $result
     * @param Param[] $parameters
     * @param int $outputMode
     *
     * @return string
     */
    public function getResult( QueryResult $result, array $parameters, $outputMode ): string {
        // Ensure $parameters is always an array
        if ($parameters === null) {
            $parameters = [];
        }

        return $this->format->buildPresenter()->presentResult(
            new SimpleQueryResult(
                $this->simplifyResult( $result ),
                $this->newProcessingResultFromParams( $parameters )
            )
        );
    }

    private function simplifyResult( QueryResult $result ): SubjectCollection {
        return ( new ResultSimplifier() )->newSubjectCollection( $result );
    }

    /**
     * This is code copied over from ParamProcessor to go from the deprecated Param[] to ProcessingResult.
     * Once the main ResultPrinter interface has been migrated away from Param this can be removed.
     */
    private function newProcessingResultFromParams( array $params ): ProcessingResult {
        $parameters = [];

        foreach ( $params as $param ) {
            $processedParam = new ProcessedParam(
                $param->getName(),
                $param->getValue(),
                $param->wasSetToDefault()
            );

            if ( !$param->wasSetToDefault() ) {
                $processedParam->setOriginalName( $param->getOriginalName() );
                $processedParam->setOriginalValue( $param->getOriginalValue() );
            }

            $parameters[$processedParam->getName()] = $processedParam;
        }

        return new ProcessingResult(
            $parameters,
            []
        );
    }

    public function getQueryMode( $context ): int {
        return SMWQuery::MODE_INSTANCES;
    }

    public function setShowErrors( $show ): void {
    }

    public function isExportFormat(): bool {
        return false;
    }

    public function getDefaultSort(): string {
        return 'ASC';
    }

    public function isDeferrable(): bool {
        return false;
    }

    public function supportsRecursiveAnnotation(): bool {
        return false;
    }

    public function setRecursiveTextProcessor( RecursiveTextProcessor $recursiveTextProcessor ): void {
    }
}