### Setup

- MW version:
- PHP version:
- DB (MySQL etc.):
- SMW version:
- MT version:
- Browsers and versions (if applicable):

### Issue

...context and general description...

**Steps to reproduce**

(recommendation is to use the [sandbox](https://sandbox.semantic-mediawiki.org))

1. ... 
2. ...
3. ...

**Expected result:** ...

**Observed result:** ...

**Stacktrace** 

```
...
```
