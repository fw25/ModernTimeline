( function ( mw ) {

    modernTimelineLog( 'Timeline script' );

    function modernTimelineLog( message ) {
        if( mw.config.get( 'debug' ) ) {
            console.log( message );
        }
    }

    mw.loader.using( [ 'ext.modern.timeline' ] ).done( function () {
       modernTimelineLog( 'Loaded timeline JS' );
       for( var timelineId in window.modernTimeline ) {
           if( window.modernTimeline.hasOwnProperty( timelineId ) ) {
               var timelineJson = window.modernTimeline[timelineId];
               if(typeof timelineJson!='undefined'){
                   switch(true){
                   case typeof timelineJson.options.start_at_end!='undefined' && timelineJson.options.start_at_end:
                       timelineJson.options.start_at_slide=parseInt(Object.keys(timelineJson.events).length)-1;
                       break;
                   case typeof timelineJson.options.event!='undefined' && timelineJson.options.event=="coming":
                       var currentDate=parseInt(modernTimelineyyyymmdd());
                       var id=0;
                       timelineJson.events.forEach(function(entry){
                           entry.text.text=entry.text.text.replace("margin: 0 0 5px 5px;","margin: 0 0 5px 0;");
                           entry.text.text=entry.text.text.replace("font-size:36px;line-height:36px;margin-left:5px;","font-size:"+tmSize+"px;line-height:"+tmSize+"px;");
                           if(parseInt(entry.start_date.year+modernTimelineZeroPad(entry.start_date.month,2)+modernTimelineZeroPad(entry.start_date.day,2))<currentDate){id++;}
                       });
                       timelineJson.options.start_at_slide=id;
                       break;
                   case typeof timelineJson.options.event!='undefined' && timelineJson.options.event=="middle":   
                       timelineJson.options.start_at_slide=parseInt(Object.keys(timelineJson.events).length/2);
                       break;
                   default:
                       var timelineJson = window.modernTimeline[timelineId];
                       
                   }
                   new TL.Timeline( timelineId, timelineJson, timelineJson.options );
               }
           }
       }
   });
   function modernTimelineZeroPad(num, places) {
     var zero = places - num.toString().length + 1;
     return Array(+(zero > 0 && zero)).join("0") + num;
   }
   function modernTimelineyyyymmdd() {
       function twoDigit(n) { return (n < 10 ? '0' : '') + n; }
       var now = new Date();
       return '' + now.getFullYear() + twoDigit(now.getMonth() + 1) + twoDigit(now.getDate());
   }

}( mediaWiki ) );